#include "belkan.h"
#include "conexion.h"
#include "environment.h"
#include <iostream>
#include <cstdlib>
#include <vector>
#include <utility>
#include <cstring>
#include<fstream> 

using namespace std;


void CapturaFilaColumnaPK (string mensaje, int &fila, int &columna){
	if (mensaje.substr(0,8)=="PK fila:"){
		int pos = mensaje.find('c');
		string valor = mensaje.substr(9,pos-8);
		fila = atoi(valor.c_str());
		
		int pos2 = mensaje.find('.');
		pos = pos+8;
		valor = mensaje.substr(pos,pos2-1);
		columna = atoi(valor.c_str());
	}
}

// -----------------------------------------------------------
void PasarVectoraMapaCaracteres(int fila, int columna, char m[200][200], char *v, int brujula){
  m[fila][columna]=v[0];

    switch(brujula){
        case 0: // Orientacion Norte

		m[fila-1][columna]=v[1];
		for (int i=0; i<3; i++){
		  m[fila-2][columna+i-1]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila-3][columna+j-2]=v[5+j];
		}
	        break;
	case 1: // Orientacion Este
		m[fila][columna+1]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+i-1][columna+2]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+j-2][columna+3]=v[5+j];
		}
	        break;
        case 2: // Orientacion Sur
		m[fila+1][columna]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+2][columna+1-i]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+3][columna+2-j]=v[5+j];
		}
		                break;
        case 3: // Orientacion Oeste
		m[fila][columna-1]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+1-i][columna-2]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+2-j][columna-3]=v[5+j];
		}

                break;
    }

}

void PasarVectoraMapaCaracteresSolucion(int fila, int columna, char m[100][100], char *v, int brujula){
  m[fila][columna]=v[0];

    switch(brujula){
        case 0: // Orientacion Norte

		m[fila-1][columna]=v[1];
		for (int i=0; i<3; i++){
		  m[fila-2][columna+i-1]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila-3][columna+j-2]=v[5+j];
		}
	        break;
	case 1: // Orientacion Este
		m[fila][columna+1]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+i-1][columna+2]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+j-2][columna+3]=v[5+j];
		}
	        break;
        case 2: // Orientacion Sur
		m[fila+1][columna]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+2][columna+1-i]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+3][columna+2-j]=v[5+j];
		}
		                break;
        case 3: // Orientacion Oeste
		m[fila][columna-1]=v[1];
		for (int i=0; i<3; i++){
		  m[fila+1-i][columna-2]=v[2+i];
		}
		for (int j=0; j<5; j++){
		  m[fila+2-j][columna-3]=v[5+j];
		}

                break;
    }

}


// -----------------------------------------------------------
void Agent::Perceive(Environment &env)
{
	env.SenSorStatus(VISTA_, SURFACE_, MENSAJE_, REINICIADO_, EN_USO_, MOCHILLA_, PUNTUACION_, FIN_JUEGO_, SALUD_, false);

}


bool Agent::Perceive_Remote(conexion_client &Cliente, Environment &env)
{
	bool actualizado=false;


	actualizado = env.Perceive_Remote(Cliente);
	if (actualizado)
		env.SenSorStatus(VISTA_, SURFACE_, MENSAJE_, REINICIADO_, EN_USO_, MOCHILLA_, PUNTUACION_, FIN_JUEGO_, SALUD_, true);

    return actualizado;
}


// -----------------------------------------------------------
string ActionStr(Agent::ActionType accion)
{
	switch (accion)
	{
	case Agent::actFORWARD: return "FORWARD";
	case Agent::actTURN_L: return "TURN LEFT";
	case Agent::actTURN_R: return "TURN RIGHT";
	case Agent::actIDLE: return "IDLE";
	case Agent::actPICKUP: return "PICK UP";
	case Agent::actPUTDOWN: return "PUT DOWN";
	case Agent::actPUSH: return "PUSH";
	case Agent::actPOP: return "POP";
	case Agent::actGIVE: return "GIVE";
	case Agent::actTHROW: return "THROW";
	default: return "????";
	}
}

// -----------------------------------------------------------
void Agent::ActualizarInformacion(Environment *env){
	// Actualizar mi informacion interna
	if (REINICIADO_){ 
		// Lo que tengas que hacer si eres reposicionado en el juego
	}
	switch(last_accion_){
	  case 0: //avanzar
	  switch(orientacion_){
	    case 0: // norte
		    y_--;
		    break;
	    case 1: // este
		    x_++;
		    break;
	    case 2: // sur
		    y_++;
		    break;
	    case 3: // oeste
		    x_--;
		    break;
	  }
	  break;
	  case 1: // girar izq
		  orientacion_=(orientacion_+3)%4;
		  break;
	  case 2: // girar dch
		  orientacion_=(orientacion_+1)%4;
		  break;
	}

	// Comprobacion para no salirme del rango del mapa
	bool algo_va_mal=false;
	if (y_<0){
		y_=0;
		algo_va_mal=true;
	} 
	else if (y_>199){
		y_=199;
		algo_va_mal=true;
	}
	if (x_<0){
		x_=0;
		algo_va_mal=true;
	} 
	else if (x_>199){
		x_=199;
		algo_va_mal=true;
	}

	if (algo_va_mal){
		cout << "CUIDADO: NO ESTAS CONTROLANDO BIEN LA UBICACION DE TU AGENTE\n";
	}


	
	
	if(VISTA_[0]=='K' && !primer_pk){
		CapturaFilaColumnaPK(MENSAJE_,y_pk1,x_pk1);
		x_f_pk1=x_;	
		y_f_pk1=y_;
		primer_pk=true;
	}else if(VISTA_[0]=='K' && !segundo_pk && (x_f_pk1 != x_ || y_f_pk1 != y_)){
		CapturaFilaColumnaPK(MENSAJE_,y_pk2,x_pk2);
		x_f_pk2=x_;	
		y_f_pk2=y_;
		segundo_pk=true;/*
		cout<<"fila: "<<y_pk1<<" columna: "<<x_pk1<<"\n";
		cout<<"fila: "<<y_f_pk1<<" columna: "<<x_f_pk1<<"\n";
		cout<<"fila: "<<y_pk2<<" columna: "<<x_pk2<<"\n";
		cout<<"fila: "<<y_f_pk2<<" columna: "<<x_f_pk2<<"\n";*/
	}
	if(primer_pk && segundo_pk && !orientada){
		int f1,f2,c1,c2;
		f1=x_pk1-x_pk2;
		f2=x_f_pk1-x_f_pk2;
		c1=y_pk1-y_pk2;
		c2=y_f_pk1-y_f_pk2;
		if(f1==-c2)
			GiraMatriz(1);
		else if(f1==-f2){
			GiraMatriz(2);
		}else if(f1==c2)
			GiraMatriz(3);
		else
			GiraMatriz(0);
		orientada=true;
	}
	PasarVectoraMapaCaracteres(y_,x_,mapa_entorno_,VISTA_,orientacion_);
	PasarVectoraMapaCaracteres(y_,x_,mapa_objetos_,SURFACE_,orientacion_);
	if(orientada)
		PasarVectoraMapaCaracteresSolucion(y_,x_,mapa_solucion_,VISTA_,orientacion_);	

	env->ActualizarMatrizUsuario(mapa_entorno_);
	
}

// -----------------------------------------------------------
Agent::ActionType Agent::Think()
{
	Agent::ActionType accion = actTURN_L; // Por defecto avanza

	
	// tomar accion
	
	switch(orientacion_){
	    case 0: // norte
	   	   if(SURFACE_[1]>='e' && tengo_obj){
	   	   		if(EN_USO_=='-')  
			   		accion =actPOP;
			   	else if(EN_USO_==ElObjeto('A') || EN_USO_==ElObjeto('B') || EN_USO_==ElObjeto('D'))
			   		accion =actPUSH;
			   	else{
			   		accion = actGIVE;
			   		tengo_obj=false;
			   	} 		
	   	   }else if(SURFACE_[0]=='0' || SURFACE_[0]=='2' || SURFACE_[0]=='6'){
				if(EN_USO_!='-')
					accion =actPUSH;
	    		else
	    			accion =actPICKUP;
	    
		   }else if((SURFACE_[0]=='9' || SURFACE_[0]=='8' || SURFACE_[0]=='5' || SURFACE_[0]=='4') && !tengo_obj){
		   		if(EN_USO_!='-')
					accion =actPUSH;
	    		else{
	    			accion =actPICKUP;
	    			tengo_obj=true;
	    		}
		   }else if(SePuedePasar(y_-1,x_,0) && HePasado(y_-1,x_)==0){
		   		camino[y_][x_]=paso;
		   		paso++;
		   		accion =actFORWARD;
		   		if(TenerObjeto(ElObjeto(VISTA_[1]))){
			   		if(EN_USO_=='-')  
			   			accion =actPOP;
			   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
			   			accion =actPUSH;
			   	}
		   }else if(SePuedePasar(y_,x_+1,1) && HePasado(y_,x_+1)==0){
		   		accion =actTURN_R;
		   }else if(SePuedePasar(y_,x_-1,3) && HePasado(y_,x_-1)==0){
		   		accion =actTURN_L;
		   }else if(SePuedePasar(y_+1,x_,2) && HePasado(y_+1,x_)==0){
		   		accion =actTURN_R;
		   }else{
		   	
		   		 switch(BuscaMejor(y_,x_)){
					case 0: // norte
						camino[y_][x_]=paso;
				   		paso++;
				   		accion =actFORWARD;
				   		if(TenerObjeto(ElObjeto(VISTA_[1]))){
					   		if(EN_USO_=='-')  
					   			accion =actPOP;
					   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
					   			accion =actPUSH;
					   	}
						break;
					case 1: // este
						accion =actTURN_R;
						break;
					case 2: // sur
						accion =actTURN_R;
						break;
					case 3: // oeste
						accion =actTURN_L;
						break;
				  }
		   }
		   
		    break;
	    case 1: // este
		   if(SURFACE_[1]>='e' && tengo_obj){
	   	   		if(EN_USO_=='-')  
			   		accion =actPOP;
			   	else if(EN_USO_==ElObjeto('A') || EN_USO_==ElObjeto('B') || EN_USO_==ElObjeto('D'))
			   		accion =actPUSH;
			   	else{
			   		accion = actGIVE;
			   		tengo_obj=false;
			   	} 		
	   	   }else if(SURFACE_[0]=='0' || SURFACE_[0]=='2' || SURFACE_[0]=='6'){
				if(EN_USO_!='-')
					accion =actPUSH;
	    		else
	    			accion =actPICKUP;
	    
		   }else if((SURFACE_[0]=='9' || SURFACE_[0]=='8' || SURFACE_[0]=='5' || SURFACE_[0]=='4') && !tengo_obj && !tengo_obj){
		   		if(EN_USO_!='-')
					accion =actPUSH;
	    		else{
	    			accion =actPICKUP;
	    			tengo_obj=true;
	    		}
		   }else if(SePuedePasar(y_,x_+1,1) && HePasado(y_,x_+1)==0){
		    	camino[y_][x_]=paso;
			   	paso++;
			   	accion =actFORWARD;
			   	if(TenerObjeto(ElObjeto(VISTA_[1]))){
			   		if(EN_USO_=='-')  
			   			accion =actPOP;
			   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
			   			accion =actPUSH;
			   	}
		   }else if(SePuedePasar(y_+1,x_,2) && HePasado(y_+1,x_)==0){
		   		accion =actTURN_R;
		   }else if(SePuedePasar(y_-1,x_,0) && HePasado(y_-1,x_)==0){
		   		accion =actTURN_L;
		   }else if(SePuedePasar(y_,x_-1,3) && HePasado(y_,x_-1)==0){
		   		accion =actTURN_R;
		   }else{
		   	
		   		 switch(BuscaMejor(y_,x_)){
					case 0: // norte
						accion =actTURN_L;
						break;
					case 1: // este
						camino[y_][x_]=paso;
				   		paso++;
				   		accion =actFORWARD;
				   		if(TenerObjeto(ElObjeto(VISTA_[1]))){
					   		if(EN_USO_=='-')  
					   			accion =actPOP;
					   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
					   			accion =actPUSH;
			   			}
						break;
					case 2: // sur
						accion =actTURN_R;
						break;
					case 3: // oeste
						accion =actTURN_R;
						break;
				  }
		   }
		   
		    break;
	    case 2: // sur
		   if(SURFACE_[1]>='e' && tengo_obj){
	   	   		if(EN_USO_=='-')  
			   		accion =actPOP;
			   	else if(EN_USO_==ElObjeto('A') || EN_USO_==ElObjeto('B') || EN_USO_==ElObjeto('D'))
			   		accion =actPUSH;
			   	else{
			   		accion = actGIVE;
			   		tengo_obj=false;
			   	} 		
	   	   }else if(SURFACE_[0]=='0' || SURFACE_[0]=='2' || SURFACE_[0]=='6'){
				if(EN_USO_!='-')
					accion =actPUSH;
	    		else
	    			accion =actPICKUP;
	    
		   }else if((SURFACE_[0]=='9' || SURFACE_[0]=='8' || SURFACE_[0]=='5' || SURFACE_[0]=='4') && !tengo_obj && !tengo_obj){
		   		if(EN_USO_!='-')
					accion =actPUSH;
	    		else{
	    			accion =actPICKUP;
	    			tengo_obj=true;
	    		}
		   }else if(SePuedePasar(y_+1,x_,2) && HePasado(y_+1,x_)==0){
		   		camino[y_][x_]=paso;
		   		paso++;
		   		accion =actFORWARD;
		   		if(TenerObjeto(ElObjeto(VISTA_[1]))){
			   		if(EN_USO_=='-')  
			   			accion =actPOP;
			   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
			   			accion =actPUSH;
			   	}
		   }else if(SePuedePasar(y_,x_-1,3) && HePasado(y_,x_-1)==0){
		   		accion =actTURN_R;
		   }else if(SePuedePasar(y_,x_+1,1) && HePasado(y_,x_+1)==0){
		   		accion =actTURN_L;
		   }else if(SePuedePasar(y_-1,x_,0) && HePasado(y_-1,x_)==0){
		   		accion =actTURN_R;
		   }else{
		   	
		   		 switch(BuscaMejor(y_,x_)){
					case 0: // norte
						accion =actTURN_R;
						break;
					case 1: // este
						accion =actTURN_L;
						break;
					case 2: // sur
						camino[y_][x_]=paso;
				   		paso++;
				   		accion =actFORWARD;
				   		if(TenerObjeto(ElObjeto(VISTA_[1]))){
					   		if(EN_USO_=='-')  
					   			accion =actPOP;
					   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
					   			accion =actPUSH;
					   	}
						break;
					case 3: // oeste
						accion =actTURN_R;
						break;
				  }
		   }
		    break;
	    case 3: // oeste
	    
			if(SURFACE_[1]>='e' && tengo_obj){
	   	   		if(EN_USO_=='-')  
			   		accion =actPOP;
			   	else if(EN_USO_==ElObjeto('A') || EN_USO_==ElObjeto('B') || EN_USO_==ElObjeto('D'))
			   		accion =actPUSH;
			   	else{
			   		accion = actGIVE;
			   		tengo_obj=false;
			   	} 		
	   	   }else if(SURFACE_[0]=='0' || SURFACE_[0]=='2' || SURFACE_[0]=='6'){
				if(EN_USO_!='-')
					accion =actPUSH;
	    		else
	    			accion =actPICKUP;
		   }else if((SURFACE_[0]=='9' || SURFACE_[0]=='8' || SURFACE_[0]=='5' || SURFACE_[0]=='4') && !tengo_obj && !tengo_obj){
		   		if(EN_USO_!='-')
					accion =actPUSH;
	    		else{
	    			accion =actPICKUP;
	    			tengo_obj=true;
	    		}
		   }else if(SePuedePasar(y_,x_-1,3) && HePasado(y_,x_-1)==0){
		   		camino[y_][x_]=paso;
		   		paso++;
		   		accion =actFORWARD;
		   		if(TenerObjeto(ElObjeto(VISTA_[1]))){
			   		if(EN_USO_=='-')  
			   			accion =actPOP;
			   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
			   			accion =actPUSH;
			   	}
		   }else if(SePuedePasar(y_-1,x_,0) && HePasado(y_-1,x_)==0){
		   		accion =actTURN_R;
		   }else if(SePuedePasar(y_+1,x_,2) && HePasado(y_+1,x_)==0){
		   		accion =actTURN_L;
		   }else if(SePuedePasar(y_,x_+1,1) && HePasado(y_,x_+1)==0){
		   		accion =actTURN_R;
		   }else{
		   	
		   		 switch(BuscaMejor(y_,x_)){
					case 0: // norte
						accion =actTURN_R;
						break;
					case 1: // este
						accion =actTURN_R;
						break;
					case 2: // sur
						accion =actTURN_L;
						break;
					case 3: // oeste
						camino[y_][x_]=paso;
				   		paso++;
				   		accion =actFORWARD;
				   		if(TenerObjeto(ElObjeto(VISTA_[1]))){
					   		if(EN_USO_=='-')  
					   			accion =actPOP;
					   		else if(EN_USO_!=ElObjeto(VISTA_[1]))
					   			accion =actPUSH;
					   	}
						break;
				  }
		   }
		    break;
	  }


	if(TenerObjeto('6'))
		cout<<"tengo botas\n";
	if(TenerObjeto('2'))
		cout<<"tengo llaves\n";
	if(TenerObjeto('0'))
		cout<<"tengo bikini\n";
	if(tengo_obj)
		cout<<"tengo obj\n";

		
	if(orientada)
		cout<<"la matriz esta orientada\n";
	
	cout<<PUNTUACION_<<"\n";
	cout<<paso<<"\n";
	cout<<"fila: "<<y_<<" columna: "<<x_<<"\n";
	
	// recuerdo la ultima accion realizada
	last_accion_ = accion;
	return accion;

}

bool Agent::SePuedePasar(int y,int x,int ori){
	bool pasar=false;
	if(mapa_entorno_[y][x]!= 'P' && mapa_entorno_[y][x]!='M' ){
		if(mapa_entorno_[y][x] =='B' && TenerObjeto('6')){
			pasar=true;
		}
		if(mapa_entorno_[y][x] == 'A' && TenerObjeto('0')){
			pasar=true;	
		}
		if(mapa_entorno_[y][x] == 'D' && TenerObjeto('2')){
			pasar=true;
		}
		if(mapa_entorno_[y][x] == 'S' || mapa_entorno_[y][x] == 'T' || mapa_entorno_[y][x] == 'K')
			pasar=true;
	}
	
	if(SURFACE_[1]>='e' && ori==orientacion_){
		camino[y][x]=paso;
		paso++;
		pasar=false;
	}
		
		
	
	return pasar;
}



bool Agent::TenerObjeto(char obj){
	bool tener=false;
	if(EN_USO_ == obj){
		tener=true;
	}else
		for(int i=0;i<5;i++)
			if(MOCHILLA_[i]==obj)
				tener=true;
		
	return tener;
}


char Agent::ElObjeto(char obj){
	char c='x';
	
	switch(obj){
		case 'A': 
			c='0';
			break;
		case 'B': 
			c='6';
			break;
		case 'D': 
			c='2';
			break;
		}
	return c;
}

int Agent::HePasado(int y,int x){
	return camino[y][x];
}


int Agent::BuscaMejor(int y,int x){
	
	int min;
	int ori;
	if(SePuedePasar(y-1,x,0)){
		ori=0;
		min=camino[y-1][x];
	}else if(SePuedePasar(y,x+1,1)){
		min=camino[y][x+1];
		ori=1;
	}else if(SePuedePasar(y+1,x,2)){
		min=camino[y+1][x];
		ori=2;
	}else if(SePuedePasar(y,x-1,2)){
		min=camino[y][x-1];
		ori=3;
	}
	
	if(min>camino[y][x+1] && SePuedePasar(y,x+1,1)){
		min=camino[y][x+1];
		ori=1;
	}
	if(min>camino[y+1][x] && SePuedePasar(y+1,x,2)){
		min=camino[y+1][x];
		ori=2;
	}
	if(min>camino[y][x-1] && SePuedePasar(y,x-1,3))
		ori=3;
	
	return ori;
}


void Agent::GiraMatriz(int giros){
	char mapa_aux_ent[200][200];
	char mapa_aux_obj[200][200];
	char mapa_aux_cam[200][200];
	int orientacion=0;
	
		
		for(int i=0;i<giros;i++){
		orientacion++;
		int x=0;
			for(int f=0;f<200;f++){
				int t=199;
				for(int c=0;c<200;c++){
					mapa_aux_ent[f][c]=mapa_entorno_[t][f];
					mapa_aux_obj[f][c]=mapa_objetos_[t][f];
					mapa_aux_cam[f][c]=camino[t][f];
					if(y_f_pk2==t && x_f_pk2==f && x==0){
						y_f_pk2=f;
						x_f_pk2=c;
						x=1;
					}
					t--;
				}
			}
			for(int f=0;f<200;f++){
				for(int c=0;c<200;c++){
					camino[f][c]=mapa_aux_cam[f][c];
					mapa_entorno_[f][c]=mapa_aux_ent[f][c];
					mapa_objetos_[f][c]=mapa_aux_obj[f][c];
				}
			}
		}
	//FUCIONA
	for(int f=0;f<101;f++){
			for(int c=0;c<101;c++){
				if(c<3 || f<3 || c>96 || f>96 ){
						mapa_solucion_[f][c]='P';
						mapa_aux_obj[f][c]='?';
						mapa_aux_cam[f][c]=0;
				}else{
				mapa_solucion_[f][c]=mapa_entorno_[y_f_pk2-y_pk2+f][x_f_pk2-x_pk2+c];
				mapa_aux_obj[f][c]=mapa_objetos_[y_f_pk2-y_pk2+f][x_f_pk2-x_pk2+c];
				mapa_aux_cam[f][c]=camino[y_f_pk2-y_pk2+f][x_f_pk2-x_pk2+c];}	
			}
		}
		for(int f=0;f<200;f++){
			for(int c=0;c<200;c++){
				if(f<100&& c<100){
					mapa_entorno_[f][c]=mapa_solucion_[f][c];
					mapa_objetos_[f][c]=mapa_aux_obj[f][c];
					camino[f][c]=mapa_aux_cam[f][c];
					
				}else{
					mapa_entorno_[f][c]='?';
					mapa_objetos_[f][c]='?';
					camino[f][c]=0;
				}
			}	
		}
		x_=x_pk2;
		y_=y_pk2;
		orientacion_=(orientacion_+orientacion)%4;
}













